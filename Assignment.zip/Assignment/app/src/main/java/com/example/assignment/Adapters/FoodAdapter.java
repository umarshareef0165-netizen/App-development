package Adapterpkg;

import static java.sql.Types.NULL;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.assignment.Model.FoodModel;
import com.example.assignment.R;

import java.util.ArrayList;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.ViewHolder> {
    ArrayList<FoodModel> arrlist;
    Context context;
    public FoodAdapter(ArrayList<FoodModel> arrlist,Context context){
        this.arrlist = arrlist;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.sample_recyclerview, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        FoodModel model = arrlist.get(position);
        holder.imgview1.setImageResource(model.getImage());
        holder.txtView.setText(model.getText());
    }

    private int modelgettext() {
        return 0;
    }

    @Override
    public int getItemCount() {
        return arrlist.size();
    }
    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView imgview1;
        TextView txtView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgview1 = itemView.findViewById(R.id.imageView);
            txtView  = itemView.findViewById(R.id.textView);
        }
    }

}



